class Fans
{
	//
}

class Star
{
	void Meet(Fans * fans)
	{
		//do something
	}
}

