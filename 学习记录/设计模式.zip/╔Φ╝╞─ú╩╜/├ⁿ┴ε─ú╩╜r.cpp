class TV
{
	void turnon();
	void turnoff();
}

class Fan
{
	void turnon();
	void turnoff();
}

class AC
{
	void turnon();
	void turnoff();
}

class Command 
{
	virtual void excute() = 0;
	virtual void undo() = 0;
}

class TVOnCommand : public Command
{
	TVOnCommand(TV * tv):m_tv(tv){}
	TV * m_tv;

	void excute() { m_tv.turnon(); }
	void undo() { m_tv.turnoff(); }
}

//...

class Ctrl
{
	std::vector<Command *> m_command_list;

	void add_command(Command * command)
	{
		m_command_list.push_back(command);
	}

	void excute_all()
	{
		for(int i = 0; i < (int)m_command_list.size(); ++i)
		{
			excute(m_command_list[i]);
		}
	}

	void undo(int index)
	{
		if(index < 0 || index >= (int)m_command_list.size())
		{
			return;
		}

		m_command_list[index].undo();
	}

	void excute(Command * command) {
		command.excute();
	}
}

int main()
{
	TV tv;
	Fan fan;
	AC ac;

	TVOnCommand * tv_on_command = new TVOnCommand(&tv);

	Ctrl ctrl;

	ctrl.excute(tv_on_command);
	//..

	return 0;
}