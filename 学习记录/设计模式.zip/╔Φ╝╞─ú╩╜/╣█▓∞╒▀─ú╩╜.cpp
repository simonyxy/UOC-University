class Observer
{
	virtual void onNotify() = 0;
}

class Subject
{
	std::vector<Observer *> m_object_list;

	void addObserver(Observer * obj) 
	{
		m_object_list.push_back(obj);
	}

	void Notify()
	{
		for(int i = 0; i < (int)m_object_list.size(); ++i)
		{
			m_object_list[i].onNotify();
		}
	}
}

class EquipmentManager : public Observer
{
	virtual void onNotify()
	{
		//do something
	}
}

class Bag : public Subject
{
	void ItemChange()
	{
		onNotify();
	}
}


