FatherView = FatherView or BaseClass(BaseView)

function FatherView:__init()
	self.father_timer = GlobalTimerQuest:AddPeriodQuest(
        function()
            print("我是爸爸")
        end,
        1,
        -1
    )
end

function FatherView:RemoveFromStage()
	if self.father_timer then
        GlobalTimerQuest:CancelQuest(self.father_timer)
        self.father_timer = nil
    end

    self:_remove()
end

function FatherView:_remove()

end

SonView = SonView or BaseClass(FatherView)

function SonView:__init()
	self.son_timer = GlobalTimerQuest:AddPeriodQuest(
        function()
            print("我是儿子")
        end,
        1,
        -1
    )
end

function SonView:_remove()
    FatherView.RemoveFromStage(self)
	if self.son_timer then
        GlobalTimerQuest:CancelQuest(self.son_timer)
        self.son_timer = nil
    end
end
