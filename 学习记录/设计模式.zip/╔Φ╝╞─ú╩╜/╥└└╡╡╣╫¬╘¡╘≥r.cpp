class Character
{
	virtual void Attack() = 0;
}

class Role 
{
	void Attack();
}

class Monster 
{
	void Attack();
}

class AIBase
{
public:
	AIBase(Character * cha):m_character(cha) {}
	virtual ~AIBase(){}

	virtual void AI(unsigned long interval)
	{
		m_character.Attack();
	}

protected:
	Character *m_character;
};