class TV
{
	void turnon();
	void turnoff();
}

class Fan
{
	void turnon();
	void turnoff();
}

class AC
{
	void turnon();
	void turnoff();
}

class Ctrl
{
	Ctrl(TV * tv, Fan * fan, AC * ac):m_tv(tv), m_fan(fan), m_ac(ac) {}

	TV * m_tv;
	Fan * m_fan;
	AC * m_ac;

	void turntvon();
	void turntvoff();
	void turnfanon();
	void turnfanoff();
	void turnacon();
	void turnacoff();
}

int main()
{
	TV tv;
	Fan fan;
	AC ac;

	Ctrl ctrl(&tv, &fan, &ac);

	ctrl.turntvon();
	//..

	return 0;
}