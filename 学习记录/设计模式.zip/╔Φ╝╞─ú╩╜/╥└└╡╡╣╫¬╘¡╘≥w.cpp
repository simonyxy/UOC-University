class Role 
{
	void Attack();
}

class Monster 
{
	void Attack();
}

class AIBase
{
public:
	AIBase(int type, Role *role, Monster *monster):m_type(type), m_role(role), m_monster(monster) {}
	virtual ~AIBase(){}

	virtual void AI(unsigned long interval)
	{
		if(type == 0)
		{
			m_role.Attack();
		}
		else if (type == 1)
		{
			m_monster.Attack();
		}
	}

protected:
	Role *m_role;
	Monster *m_monster;
};