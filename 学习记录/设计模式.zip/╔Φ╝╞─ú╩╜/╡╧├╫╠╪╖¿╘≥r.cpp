class Fans
{
	//
}

class Star
{
	//
}

class Company
{
	void Meet(Star * star, Fans * fans)
	{
		//do something
	}
}

