class HeroineState
{
public:
  virtual ~HeroineState() {}
  virtual HeroineState* handleInput(Heroine& heroine, Input input) {}
};

class DuckingState : public HeroineState
{
public:
  DuckingState()
  : chargeTime_(0)
  {}

  virtual HeroineState* handleInput(Heroine& heroine, Input input) {
    if (input == PRESS_DOWN)
    {
      // 改回站立状态……
      heroine.setGraphics(IMAGE_STAND);
      return new DuckingState();
    }

    // 保持这个状态
    return NULL;
  }
};

class Heroine
{
public:
  virtual void handleInput(Input input)
  {
    HeroineState* state = state_->handleInput(*this, input);
    if (state != NULL)
    {
      delete state_;
      state_ = state;
    }
  }

  // 其他方法……
private:
  HeroineState* state_;
};



